<?php

namespace AI;

abstract class AIFoundation
{
    abstract public function execute();
}
