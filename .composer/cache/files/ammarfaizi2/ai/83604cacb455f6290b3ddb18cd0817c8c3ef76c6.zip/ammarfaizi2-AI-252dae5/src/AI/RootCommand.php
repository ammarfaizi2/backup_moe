<?php

namespace AI;

use App\SaferScript;

/**
 *   @author Ammar Faizi <ammarfaizi2@gmail.com>
 */

trait RootCommand
{
}
