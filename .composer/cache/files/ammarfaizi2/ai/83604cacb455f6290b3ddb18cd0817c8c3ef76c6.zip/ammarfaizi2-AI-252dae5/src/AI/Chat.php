<?php

namespace AI;

/**
 *   @author Ammar Faizi <ammarfaizi2@gmail.com>
 */

trait Chat
{
}
