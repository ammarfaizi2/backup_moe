<?php

namespace AI;

/*use App\Brainly;
use App\ChitChat;
use AI\PHPVirtual;
use App\WhatAnime;
use App\MyAnimeList;
use App\SaferScript;
use App\JadwalSholat;
use Teacrypt\Teacrypt;
use App\GoogleTranslate;*/

/**
 *   @author Ammar Faizi <ammarfaizi2@gmail.com>
 */

trait Command
{
}
